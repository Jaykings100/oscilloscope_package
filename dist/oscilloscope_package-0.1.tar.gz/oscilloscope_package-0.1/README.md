# Oscilloscope Package

This package provides a class for controlling an oscilloscope.

## Installation

You can install this package using `pip`:

```bash
pip install oscilloscope_package
